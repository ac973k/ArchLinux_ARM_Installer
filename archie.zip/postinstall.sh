#!/bin/bash

export PATH=/sbin:/usr/bin:/bin

source /etc/profile
source ~/.bashrc

export PS1="(chroot) $PS1"

echo "Настраиваем..."

pacman -Syu

pacman -S --force core

echo "Готово =)"